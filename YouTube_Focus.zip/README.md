# YouTube_Focus
YouTube Focus is an add-on who tries to promote a healthier browsing at youtube.com. YouTube has one billion hours whatched daily, and it’s recommendation algorithm generates more than 70% of views. That means 700.000.000 hours every single day. What means that the greatest slice of time that people spend on YouTube isnt because they searched for something to whatch or something to learn, it is because they were sugested by YouTube's algorithm.

Algorithm's operation is secret, but some researshers, like Gillaume Chaslot, are claiming that the Youtube's alorithm [drives people to divisive content](https://www.wsj.com/articles/how-youtube-drives-viewers-to-the-internets-darkest-corners-1518020478) and promotes [conspirancy theory videos.](https://www.theguardian.com/technology/2018/feb/02/how-youtubes-algorithm-distorts-truth)

So, our add-on tries to deal with that offering two ways:

### **Youtube Focus Mode:**
+ Disable the recommended videos at the **home page**.
+ just allow **three suggested videos** at the "up next list".

### **Youtube Brain Mode:**
+ Disable all the recommendations. _Daring you to enable your brain_.

Finelly, if you want the Youtube's recomendations back you can do that with a single click.
